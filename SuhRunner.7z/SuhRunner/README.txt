SuhRunner - Endless Runner Game

CMPT 365 - Multimedia Systems Term Project

Created by:
Brandon Nguyen, brandonn@sfu.ca, 301219561
Davorin Doung, ddoung@sfu.ca, 301234931

DATE: April 11 2016

Description of Game:
	Our player is dropped into a hellish world made of flames and purple smoke and must avoid capture by the hands of deadly ghouls.
	The longer your time being alive, the better your score.

Instructions to run application:
	1. Open "Builds" folder,
	2. Open "PC, Mac & Linux Standalone" folder,
	3. Run "SuhRunner.exe" application
	4. Choose desired screen resolution, graphics quality, and monitor
	5. Select windowed for windowed mode or leave unchecked for fullscreen, and press "Play!"

Instructions to play the game:
	1. Press any button to start and play the game
	2. Player will constantly be falling, press any button to make him jump, keeping him in the air
	3. Fly in-between ghost obstacles without touching them for as long as possible to achieve a high score
	4. Follow on screen prompts to continue the game
	5. Press alt+f4 to quit the application
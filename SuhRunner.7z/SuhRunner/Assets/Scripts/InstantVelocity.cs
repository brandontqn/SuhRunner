﻿using UnityEngine;
using System.Collections;

//moving obstacles
public class InstantVelocity : MonoBehaviour {

	public Vector3 velocity = Vector2.zero;

	private Rigidbody2D body2d;

	// Use this for initialization
	void Awake () {
		body2d = GetComponent<Rigidbody2D>();
	}
	
	void FixedUpdate(){
		body2d.velocity = velocity;
	}
}

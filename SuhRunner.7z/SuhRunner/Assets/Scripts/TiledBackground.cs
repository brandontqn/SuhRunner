﻿using UnityEngine;
using System.Collections;

//repeat our background texture
public class TiledBackground : MonoBehaviour {

	public int textureSize = 32;
	public bool scaleHorizontally = true;
	public bool scaleVertically = true;

	// Use this for initialization
	void Start () {

		//newW/H = 1 or ceiling of scaled W/H
		var newWidth = !scaleHorizontally ? 1 : Mathf.Ceil (Screen.width / (textureSize * PixelPerfectCamera.scale));
		var newHeight = !scaleVertically ? 1 : Mathf.Ceil (Screen.height / (textureSize * PixelPerfectCamera.scale));

		//new local scale
		transform.localScale = new Vector3 (newWidth * textureSize, newHeight * textureSize, 1);

		//new Texture scale
		GetComponent<Renderer>().material.mainTextureScale = new Vector3(newWidth, newHeight, 1);
	}
}

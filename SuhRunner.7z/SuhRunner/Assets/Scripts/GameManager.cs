﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;
using System;

public class GameManager : MonoBehaviour {

	public GameObject playerPrefab;
	public float lastTime;
	public bool rdy;

	private bool gameStarted;
	//private TimeManager timeManager;
	private GameObject player;
	private GameObject floor;
	private Spawner spawner;
	private InputState inputState;

	private float blinkTime = 0f;
	private bool blink;
	private float timeElapsed = 0f;
	private float BestTime = 0f;

	public Text startText;
	public Text scoreText;
	public Text gameoverText;

	void Awake(){
		//timeManager = GetComponent<TimeManager> ();
		floor = GameObject.Find ("Fire");
		spawner = GameObject.Find ("Generator").GetComponent<Spawner>();
		inputState = GetComponent<InputState> ();
	}

	// Use this for initialization
	void Start () {
		var floorHeight = floor.transform.localScale.y;

		var pos = floor.transform.position;
		pos.x = 0;
		pos.y = -((Screen.height / PixelPerfectCamera.pixelsToUnits)/2) + floorHeight/2;
		floor.transform.position = pos;

		spawner.active = false;
		//Time.timeScale = 0;

		BestTime = PlayerPrefs.GetFloat ("BestTime");

		lastTime = -3;
	}
	
	// Update is called once per frame
	void Update () {
		
		//if (gameStarted != true && Time.timeScale == 0) {
		if (gameStarted != true) {
			rdy = (Time.time - lastTime) > 3.0f;
			if (rdy) {
				if (Input.anyKeyDown) {
					//timeManager.ManipulateTime (1, 1f);
					ResetGame ();
				}
			}

		}
		if (!gameStarted) {
			blinkTime ++;

			if (blinkTime % 40 == 0) {
				blink = !blink;
			}

			startText.canvasRenderer.SetAlpha (blink ? 0 : 1);
			scoreText.text = "TIME: " + FormatTime (timeElapsed) + "\nBEST: " + FormatTime (BestTime);
		}
		else {
			timeElapsed += Time.deltaTime;
			scoreText.text = "TIME: " + FormatTime(timeElapsed);
		}
	}

	void OnPlayerKilled(){
		//stop spawner after player is killed
		spawner.active = false;

		var playerDestroyScript = player.GetComponent<DestroyOffscreen> ();
		playerDestroyScript.DestroyCallback -= OnPlayerKilled;
		var playerKillScript = player.GetComponent<Jump> ();
		playerKillScript.killed -= OnPlayerKilled;
		//reset velocity for the restart game player animation
		player.GetComponent<Rigidbody2D>().velocity = Vector2.zero;
		//timeManager.ManipulateTime (0, 5.5f);

		gameStarted = false;



		gameoverText.text = "GAME OVER";

		startText.text = "PRESS ANY BUTTON TO RESTART";

		if (timeElapsed > BestTime) {
			BestTime = timeElapsed;
			PlayerPrefs.SetFloat ("BestTime", BestTime);
		}
	}

	void ResetGame(){
		lastTime = Time.time;
		gameoverText.text = "";
		//turn on spawner when game restarts
		spawner.active = true;
		//player drop animation start position
		player = GameObjectUtil.Instantiate(playerPrefab, new Vector3(-66, (Screen.width / PixelPerfectCamera.pixelsToUnits)/2 - 100,0));

		//reference to when player is destroyed, when true, call back delegate is linked to onplayerkilled
		var playerDestroyScript = player.GetComponent<DestroyOffscreen> ();
		playerDestroyScript.DestroyCallback += OnPlayerKilled;
		var playerKillScript = player.GetComponent<Jump> ();
		playerKillScript.killed += OnPlayerKilled;

		gameStarted = true;

		startText.canvasRenderer.SetAlpha(0);

		timeElapsed = 0;
	}

	string FormatTime(float value){
		TimeSpan t = TimeSpan.FromSeconds (value);

		return string.Format("{0:D2}:{1:D2}", t.Minutes, t.Seconds);
	}
}

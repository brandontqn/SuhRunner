﻿using UnityEngine;
using System.Collections;

public class Obstacle : MonoBehaviour {
	public Vector2 verticalshiftrange = new Vector2 (-22f, 22f);

	void Start () {
		transform.position = new Vector3 (transform.position.x, transform.position.y - Random.Range (verticalshiftrange.x, verticalshiftrange.y), transform.position.z); 
	}

}

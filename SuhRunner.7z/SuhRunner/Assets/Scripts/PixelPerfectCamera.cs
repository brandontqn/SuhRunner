﻿using UnityEngine;
using System.Collections;

//scale our camera to fit the screen of any resolution
public class PixelPerfectCamera : MonoBehaviour {

    public static float pixelsToUnits = 1f;
    public static float scale = 1f;

	//standard resolution for old gameboys, one of oldest resolution standards, we scale up from here
    public Vector2 nativeResolution = new Vector2(240, 160);

	void Awake () {
        var camera = GetComponent<Camera>();

        if (camera.orthographic)
        {
            scale = Screen.height / nativeResolution.y;
            pixelsToUnits *= scale;
			//divide by 2 because camera is centered in the middle
            camera.orthographicSize = (Screen.height / 2.0f) / pixelsToUnits;
        }
	}
}

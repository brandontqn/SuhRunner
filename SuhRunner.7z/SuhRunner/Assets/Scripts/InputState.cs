﻿using UnityEngine;
using System.Collections;

public class InputState : MonoBehaviour {


	public bool actionButton, dead;
	public float absPosX1 = 0f, absPosX2 = 0f;

	private Rigidbody2D body2d;

	void Awake(){
		body2d = GetComponent<Rigidbody2D> ();
		absPosX1 = System.Math.Abs (body2d.position.x);
	}

	// Update is called once per frame
	void Update () {
		actionButton = Input.anyKeyDown;
	}

	//physics should be in fixed update instead of update
	void FixedUpdate(){
		absPosX2 = absPosX1;
		absPosX1 = System.Math.Abs (body2d.position.x);

		//player dies when X position changes  (he hits a ghost)
		dead = System.Math.Abs(absPosX1-absPosX2) != 0;
	}

	//on a collision, player dies
	void OnCollisionEnter2D(Collision2D other){
		dead = true;
	}
}

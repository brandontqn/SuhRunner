﻿using UnityEngine;
using System.Collections;

//automatically spawn obstacles to throw at player
public class Spawner : MonoBehaviour {

	public GameObject[] prefabs;
	public float delay = 2.0f;
	public bool active = true;
	public Vector2 delayRange = new Vector2(1,2);

	// Use this for initialization
	void Start () {
		ResetDelay();
		//"loop" that runs seperately
		StartCoroutine (EnemyGenerator ());
	}

	//defining CoRoutine
	IEnumerator EnemyGenerator(){
		yield return new WaitForSeconds (delay);

		if (active) {
			//position we want to spawn things at
			var newTransform = transform;
			//generate random obstacles at our transform position, quaternion resets rotation position to 0
			GameObjectUtil.Instantiate (prefabs [Random.Range (0, prefabs.Length)], newTransform.position);
			ResetDelay();
		}

		StartCoroutine (EnemyGenerator ());
	}

	void ResetDelay(){
		delay = Random.Range (delayRange.x, delayRange.y);
	}
}

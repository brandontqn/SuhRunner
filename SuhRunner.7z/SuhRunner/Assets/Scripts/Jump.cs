﻿using UnityEngine;
using System.Collections;

public class Jump : MonoBehaviour {
	public AudioSource audioSource, audioSource2;
	public float jumpSpeed = 150;

	public delegate void OnKilled();
	public event OnKilled killed;
	private Rigidbody2D body2d;
	private InputState inputState;

	// Use this for initialization
	void Start () {
		body2d = GetComponent<Rigidbody2D> ();
		inputState = GetComponent<InputState> ();
	}

	// Update is called once per frame
	void Update () {
		if (!inputState.dead) {
			if (inputState.actionButton) {
				body2d.velocity = new Vector2 (0, jumpSpeed);
				audioSource.Play ();
			}
		} else {
			GameObjectUtil.Destroy(gameObject);
			audioSource2.Play ();
			killed ();	
		}
	}
}
